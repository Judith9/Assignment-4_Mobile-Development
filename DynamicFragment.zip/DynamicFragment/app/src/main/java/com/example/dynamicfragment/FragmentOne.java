package com.example.dynamicfragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import static com.example.dynamicfragment.MainActivity.fragmentManager;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 *
 * to handle interaction events.
 */
public class FragmentOne extends Fragment {

//    private OnFragmentInteractionListener mListener;
    public Button button;
    public Button button2;


    public FragmentOne() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_fragment_one, container, false);

        button = view.findViewById(R.id.f1Button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentTransaction ft = getFragmentManager().beginTransaction();

                    FragmentTwo frag2 = new FragmentTwo();
                    ft.replace(R.id.FragmentContainer1, frag2, null);
                    ft.addToBackStack("frag1");
                    ft.commit();
                }




        });


        return view;

    }


}
